const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static("public")); // Serve frontend

// Movie and booking data
let movies = [
  { id: 1, title: "IHostage", seats: 5 },
  { id: 2, title: "HAVOC", seats: 10 },
  { id: 3, title: "Weak Hero", seats: 4 },
  { id: 4, title: "Memory", seats: 8 },
  { id: 5, title: "Deep Impact", seats: 15 },
  { id: 6, title: "Jewel Thief", seats: 6 },
];

let bookings = [];
let bookingId = 1;

// Routes
app.get("/movies", (req, res) => {
  res.json(movies);
});

app.post("/book", (req, res) => {
  const { movieId, customer } = req.body;

  if (!customer || typeof customer !== 'string' || customer.trim() === '') {
    return res.status(400).json({ message: "Customer name is required." });
  }

  const movie = movies.find(m => m.id === movieId);

  if (!movie) {
    return res.status(404).json({ message: "Movie not found." });
  }

  if (movie.seats <= 0) {
    return res.status(400).json({ message: "No seats available." });
  }

  movie.seats--;
  const newBooking = { id: bookingId++, movieTitle: movie.title, customer: customer.trim() };
  bookings.push(newBooking);
  res.json({ message: `Booked ${movie.title} for Customer: ${customer.trim()}` });
});

app.get("/bookings", (req, res) => {
  res.json(bookings);
});

app.delete("/cancel/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const index = bookings.findIndex(b => b.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "Booking not found." });
  }

  const movie = movies.find(m => m.title === bookings[index].movieTitle);
  if (movie) movie.seats++;

  bookings.splice(index, 1);
  res.json({ message: "Booking cancelled." });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${3000}`));
